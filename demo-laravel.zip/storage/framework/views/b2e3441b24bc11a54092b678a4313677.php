<!DOCTYPE html>
<html>

<head>
    <title>Hola Laravel</title>
</head>

<body>
    <h1>¡Laravel funciona! 🚀</h1>
</body>

</html>
<?php /**PATH E:\Saul\Mis-Projectos\demo-laravel\resources\views/hola.blade.php ENDPATH**/ ?>