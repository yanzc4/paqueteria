<!DOCTYPE html>
<html>

<head>
    <title>Hola Laravel</title>
</head>

<body>
    <h1>¡Laravel funciona! 🚀</h1>
</body>

</html>
